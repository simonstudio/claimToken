git add .
git commit -m "a" 
# git push --set-upstream origin mastergit
# git remote add  origin https://github.com/simonstudio/landwind.git
git push