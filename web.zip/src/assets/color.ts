export const COLOR_PRIMARY = '#000';
export const COLOR_SECONDARY = '#00000080';
export const COLOR_BLUE = '#0d6efd';