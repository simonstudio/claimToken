
export type ReduxDispatchRespone = {
    meta: any,
    payload: any,
    type: string,
    error?: any
}

export default {}