
yarn add @fortawesome/fontawesome-svg-core @fortawesome/free-solid-svg-icons @fortawesome/react-fontawesome


yarn add millify axios moment moment-duration-format moment-timer moment-timezone ethers react-redux @reduxjs/toolkit react-router-dom sass scss stream url web3 ws crypto crypto-browserify crypto-js  bignumber.js   i18next i18next-browser-languagedetector i18next-http-backend react-i18next


