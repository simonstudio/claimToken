# /D/xampp/php/php.exe -t ./public/ -S localhost:81
npm start &
/D/xampp/mysql_start.bat
