
yarn add    @fortawesome/fontawesome-svg-core @fortawesome/free-solid-svg-icons @fortawesome/react-fontawesome @reduxjs/toolkit bignumber.js axios crypto crypto-browserify crypto-js ethers  i18next i18next-browser-languagedetector i18next-http-backend react-i18next

yarn add millify moment moment-duration-format moment-timer moment-timezone react-redux react-router-dom sass scss stream url web3 ws 

